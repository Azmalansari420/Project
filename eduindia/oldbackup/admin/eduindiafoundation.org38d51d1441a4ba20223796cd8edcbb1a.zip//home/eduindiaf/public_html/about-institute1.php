<?php 
include("header.php");
    $get_url    = @$_GET['id'];
	$table_name = "institutes";
	$c_page = "about-course.php";
	if(isset($get_url) and !empty($get_url) and is_numeric($get_url)==1){
		$fs = fs($table_name,array('id'=>$get_url));   
		if(is_array($fs) || is_object($fs)){
			
		}else{
			goto_c_url('Our-Institutes.php');
		}
	}else{
		goto_c_url('Our-Institutes.php');
	}
?>


<div class="inner-banner has-base-color-overlay text-center" style="background: url(galleryimages/backgournd.jpg);">
    <div class="container">
        <div class="box">
            <h3><?php e($fs->name); ?></h3>
        </div><!-- /.box -->
    </div><!-- /.container -->
</div>



<div class="container" style="margin-top:10%;">


  <ul class="nav nav-pills nav-justified nav-tabs">
    <li class="active"><a data-toggle="tab" href="#home">Department of Computer</a> </li>
    <li><a data-toggle="tab" href="#menu2">Department of Accounting</a> </li>
    <li><a data-toggle="tab" href="#menu3">Department of Designing</a> </li>
    <li><a data-toggle="tab" href="#menu4">Department of hardware & Networking</a> </li>
    <li><a data-toggle="tab" href="#menu5">Department of Management</a> </li>
  </ul>

  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">     
          <h2>Department of Computer</h2>
          <p>Computer science is the study of the theory, experimentation, and engineering that form the basis for the design and use of computers..</p>
          <p>It is the scientific and practical approach to computation and its applications and the systematic study of the feasibility, structure, expression, and mechanization of the methodical procedures (or algorithms) that underlie the acquisition, representation, processing, storage, communication of, and access to information. An alternate, more succinct definition of computer science is the study of automating algorithmic processes that scale.</p>
          <p>A computer scientist specializes in the theory of computation and the design of computational systems.</p>
          <div class="section-title">
            <h2>All Courses List</h2>
          </div>
          <table class="table table-bordered">
            <tr>
              <td class="text-center font-16 font-weight-600 bg-theme-color-2 text-white" colspan="4">Courses Criteria</td>
            </tr>
            <tr>
              <th>Sr. no.</th>
              <th>Course Name</th>
              <th>Duration</th>
            </tr>
            <tbody>
              <tr>
                <th scope="row">1</th>
                <td>Certificate In Computer Application</td>
                <td>Three Month</td>
              </tr>
              <tr>
                <th scope="row">2</th>
                <td>Certificate In Office Automation</td>
                <td>Three Month</td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <td>Certificate In Desktop Publication</td>
                <td>Three Month</td>
              </tr>
              <tr>
                <th scope="row">4</th>
                <td>Certificate In Information Technology</td>
                <td>Three Month</td>
              </tr>
              <!-- Diploma Courses -->
              <tr>
                <th scope="row">5</th>
                <td>Diploma In Computer Application</td>
                <td>Six Month</td>
              </tr>
              <tr>
                <th scope="row">6</th>
                <td>Diploma In Office Automation</td>
                <td>Six Month</td>
              </tr>
              <tr>
                <th scope="row">7</th>
                <td>Diploma In Desktop Publication</td>
                <td>Six Month</td>
              </tr>
              <tr>
                <th scope="row">8</th>
                <td>Diploma In Information Technology</td>
                <td>Six Month</td>
              </tr>
              <!-- Advance Diploma Courses -->
              <tr>
                <th scope="row">9</th>
                <td>Advance Diploma In Computer Application</td>
                <td>One Year</td>
              </tr>
              <tr>
                <th scope="row">10</th>
                <td>Advance Diploma In Office Automation</td>
                <td>One Year</td>
              </tr>
              <tr>
                <th scope="row">11</th>
                <td>Advance Diploma In Desktop Publication</td>
                <td>One Year</td>
              </tr>
              <tr>
                <th scope="row">12</th>
                <td>Advance Diploma In Information Technology</td>
                <td>One Year</td>
              </tr>
              <!-- Master Diploma Courses -->
              <tr>
                <th scope="row">13</th>
                <td>Master Diploma In Computer Information & System Management</td>
                <td>One Year</td>
              </tr>
              <tr>
                <th scope="row">14</th>
                <td>Master Diploma In Computer Application</td>
                <td>One Year</td>
              </tr>
            </tbody>
          </table>
        
    </div>
  
    <div id="menu2" class="tab-pane fade">
     
		<h2>Department of Accounting</h2>
<p>Accounting or accountancy is the measurement, processing, and communication of financial information about economic entities such as businesses and corporations.</p>
<p>The modern field was established by the Italian mathematician Luca Pacioli in 1494.</p> <p>Accounting, which has been called the "language of business", measures the results of an organization's economic activities and conveys this information to a variety of users, including investors, creditors, management, and regulators.</p>

<p>Practitioners of accounting are known as accountants. The terms "accounting" and "financial reporting" are often used as synonyms.</p>
		  <div class="section-title">
            <h2>All Courses List</h2>
          </div>
		  <table class="table table-bordered"> 
                    <tr><td class="text-center font-16 font-weight-600 bg-theme-color-2 text-white" colspan="4">Courses Criteria</td></tr>
                    <tr> <th>Sr. no.</th> <th>Course Name</th> <th>Duration</th> </tr>
                    <tbody> 
                    <tr> <th scope="row">1</th> 	<td>Certificate In Tally 9.0</td> 				<td>Three Month</td> 	</tr>
					<tr> <th scope="row">2</th> 	<td>Certificate In Sap</td>  					<td>Three Month</td> 	</tr>
					<tr> <th scope="row">3</th> 	<td>Certificate In Computer Accounting</td>  	<td>Three Month</td> 	</tr>
                    <!-- Diploma Courses -->                                    	
					<tr> <th scope="row">4</th> 	<td>Diploma In Tally 9.0</td>  				<td>Six Month</td> 	</tr>
                    <tr> <th scope="row">5</th> 	<td>Diploma In Sap</td>  					<td>Six Month</td> 	</tr>
                    <tr> <th scope="row">6</th> 	<td>Diploma In Computer Accounting</td>  	<td>Six Month</td> 	</tr>                     	                    
                    <!-- Advance Diploma Courses -->                                    	
					<tr> <th scope="row">7</th> 	<td>Advance Diploma In Tally 9.0</td>  			<td>One Year</td> 	</tr>
                    <tr> <th scope="row">8</th> 	<td>Advance Diploma In Sap</td>  				<td>One Year</td> 	</tr>     
                    <tr> <th scope="row">9</th> 	<td>Advance Diploma Computer Accounting</td>  	<td>One Year</td> 	</tr>
                    </tbody> 
                  </table>

		
    </div>
    <div id="menu3" class="tab-pane fade">
      
			<h2>Department of Designing</h2>
<p>The terms design computing and other relevant terms including design and computation and computational design refer to the study and practice of design activities through the application and development of novel ideas and techniques in computing. One of the early groups to coin this term was the Key Centre of Design Computing and Cognition at the University of Sydney in Australia, which for nearly forty years (late 1960s to early 2000s) pioneered in the research, teaching, and consulting of design and computational technologies.</p>
<p>This group organised the academic conference series "Artificial Intelligence in Design (AID)" published by Springer during that period. AID was later renamed "Design Computing and Cognition (DCC)" and is currently a leading biannual conference in the field. Other notable groups in this area are the Design and Computation group at Massachusetts Institute of Technology's School of Architecture + Planning and the Computational Design group at Georgia Tech.</p>

<p>Whilst these terms share in general an interest in computational technologies and design activity, there are important differences in the various approaches, theories, and applications. For example, while in some circles the term Computational Design refers in general to the creation of new computational tools and methods in the context of Computational Thinking, Design Computing is concerned with bridging these two fields in order to build an increased understanding of design</p>
<div class="section-title">
            <h2>All Courses List</h2>
          </div>
		  <table class="table table-bordered"> 
                    <tr><td class="text-center font-16 font-weight-600 bg-theme-color-2 text-white" colspan="4">Courses Criteria</td></tr>
                    <tr> <th>Sr. no.</th> <th>Course Name</th> <th>Duration</th> </tr>
                    <tbody> 
                    <tr> <th scope="row">1</th> 	<td>Certificate In CorelDRAW</td> 					<td>Three Month</td> 	</tr>
					<tr> <th scope="row">2</th> 	<td>Certificate In Photoshop</td>  					<td>Three Month</td> 	</tr>
					<tr> <th scope="row">3</th> 	<td>Certificate In Indesign</td>  					<td>Three Month</td> 	</tr>
                    <tr> <th scope="row">4</th> 	<td>Certificate In AutoCAD</td>  					<td>Three Month</td> 	</tr>
                    <tr> <th scope="row">5</th> 	<td>Certificate In Web Designing</td> 				<td>Three Month</td> 	</tr>
					<tr> <th scope="row">6</th> 	<td>Certificate In Web Development</td>  			<td>Three Month</td> 	</tr>                   
                    <!-- Diploma Courses -->                                    	
					<tr> <th scope="row">7</th> 	<td>Diploma In AutoCAD</td>  				<td>Six Month</td> 	</tr>
                    <tr> <th scope="row">8</th> 	<td>Diploma In Web Designing</td>  			<td>Six Month</td> 	</tr>
                    <tr> <th scope="row">9</th> 	<td>Diploma In Web Development</td>  		<td>Six Month</td> 	</tr>  
                   	<tr> <th scope="row">10</th> 	<td>Diploma In Interior Designing</td>  	<td>Six Month</td> 	</tr>
                    <tr> <th scope="row">11</th> 	<td>Diploma In 2-D Animation</td>  			<td>Six Month</td> 	</tr>
                    <tr> <th scope="row">12</th> 	<td>Diploma In 3-D Animation</td>  			<td>Six Month</td> 	</tr>     
                    <tr> <th scope="row">12</th> 	<td>Diploma In V-Ray Rendering</td>  		<td>Six Month</td> 	</tr>                     
                    <!-- Diploma Courses -->                                    	
					<tr> <th scope="row">13</th> 	<td>Advance Diploma In AutoCAD</td>  					<td>One Year</td> 	</tr>
                    <tr> <th scope="row">14</th> 	<td>Advance Diploma In Graphic Designing</td>  			<td>One Year</td> 	</tr>     
                    <tr> <th scope="row">15</th> 	<td>Advance Diploma In Printing Lab Technology</td>  	<td>One Year</td> 	</tr>
                    <tr> <th scope="row">16</th> 	<td>Advance Diploma In Fashion Designing</td>  			<td>One Year</td> 	</tr>
                    <tr> <th scope="row">17</th> 	<td>Advance Diploma In Web Designing</td>  				<td>One Year</td> 	</tr>     
                    <tr> <th scope="row">18</th> 	<td>Advance Diploma In Web Development</td>  			<td>One Year</td> 	</tr> 
                    <tr> <th scope="row">19</th> 	<td>Advance Diploma In Interior Designing</td>  		<td>One Year</td> 	</tr>
                    <tr> <th scope="row">20</th> 	<td>Advance Diploma In 2-D Animation</td>  				<td>One Year</td> 	</tr>     
                    <tr> <th scope="row">21</th> 	<td>Advance Diploma In 3-D Animation</td>  				<td>One Year</td> 	</tr> 
                    <tr> <th scope="row">22</th> 	<td>Advance Diploma In V-Ray Rendering</td>  			<td>One Year</td> 	</tr>
                    </tbody> 
                  </table>

		
    </div>
     <div id="menu4" class="tab-pane fade">
     
			<h2>Department of hardware & Networking</h2>
			<i>Networking hardware, also known as network equipment or computer networking devices, are physical devices which are required for communication and interaction between devices on a computer network. Specifically, they mediate data in a computer network. Units which are the last receiver or generate data are called hosts or data terminal equipment.</i>
			<p>Networking devices may include gateways, routers, network bridges, modems, wireless access points, networking cables, line drivers, switches, hubs, and repeaters; and may also include hybrid network devices such as multilayer switches, protocol converters, bridge routers, proxy servers, firewalls, network address translators, multiplexers, network interface controllers, wireless network interface controllers, ISDN terminal adapters and other related hardware.</p>

<p>The most common kind of networking hardware today is a copper-based Ethernet adapter which is a standard inclusion on most modern computer systems. Wireless networking has become increasingly popular, especially for portable and handheld devices.Other networking hardware used in computers includes data center equipment (such as file servers, database servers and storage areas), network services (such as DNS, DHCP, email, etc.) as well as devices which assure content delivery.Taking a wider view, mobile phones, PDAs and even modern coffee machines may also be considered networking hardware. As technology advances and IP-based networks are integrated into building infrastructure and household utilities, network hardware will become an ambiguous term owing to the vastly increasing number of "network capable" endpoints.</p>
<div class="section-title">
            <h2>All Courses List</h2>
          </div>
<table class="table table-bordered"> 
                    <tr><td class="text-center font-16 font-weight-600 bg-theme-color-2 text-white" colspan="4">Courses Criteria</td></tr>
                    <tr> <th>Sr. no.</th> <th>Course Name</th> <th>Duration</th> </tr>
                    <tbody> 
                    <tr> <th scope="row">1</th> 	<td>Diploma In Hardware & Networking Engineer</td>  				<td>Six Month</td> 	</tr>
                    <tr> <th scope="row">2</th> 	<td>Diploma In Networking Engineer</td>  							<td>Six Month</td> 	</tr>
                   	<!-- Advance Diploma Courses -->                                    	
					<tr> <th scope="row">3</th> 	<td>Advance Diploma In Hardware & Networking</td>  					<td>One Year</td> 	</tr>
                    <tr> <th scope="row">4</th> 	<td>Advance Diploma In Hardware & Networking Administrator</td>  	<td>One Year</td> 	</tr>     
                    <tr> <th scope="row">5</th> 	<td>Advance In Hardware & Networking Engineer</td>  				<td>One Year</td> 	</tr>
                    <tr> <th scope="row">6</th> 	<td>Advance Diploma In Networking Engineer</td>  					<td>One Year</td> 	</tr>
                   	<tr> <th scope="row">7</th> 	<td>Industrial Diploma In Hardware & Networking</td>  				<td>Two Year</td> 	</tr>
                    <tr> <th scope="row">8</th> 	<td>Industrial Diploma In Hardware & Networking Administrator</td>  <td>Two Year</td> 	</tr>
                    </tbody> 
                  </table>

			
		
    </div>
     <div id="menu5" class="tab-pane fade">
     
			<h2>Department of Management</h2>
			<i>Management (or managing) is the administration of an organization, whether it is a business, a not-for-profit organization, or government body. Management includes the activities of setting the strategy of an organization and coordinating the efforts of its employees (or of volunteers) to accomplish its objectives through the application of available resources, such as financial, natural, technological, and human resources. The term "management" may also refer to those people who manage an organization.</i>
			<p>Social scientists study management as an academic discipline, investigating areas such as social organization and organizational leadership. Some people study management at colleges or universities; major degrees in management include the Bachelor of Commerce (B.Com.) and Master of Business Administration (MBA.) and, for the public sector, the Master of Public Administration (MPA) degree.</p>

<p>Individuals who aim to become management specialists or experts, management researchers, or professors may complete the Doctor of Management (DM), the Doctor of Business Administration (DBA), or the PhD in Business Administration or Management.</p>
<div class="section-title">
            <h2>All Courses List</h2>
          </div>
<table class="table table-bordered"> 

                    <tr><td class="text-center font-16 font-weight-600 bg-theme-color-2 text-white" colspan="4">Courses Criteria</td></tr>

                    <tr> <th>Sr. no.</th> <th>Course Name</th> <th>Duration</th> </tr>

                    <tbody> 

                    <tr> <th scope="row">1</th> 	<td>Diploma In Export Import Management</td>  				<td>Six Month</td> 	</tr>

                    <tr> <th scope="row">2</th> 	<td>Diploma In Retail Management</td>  						<td>Six Month</td> 	</tr>

                    <tr> <th scope="row">3</th> 	<td>Diploma In Business Management</td>  					<td>Six Month</td> 	</tr>

				    <tr> <th scope="row">4</th> 	<td>Advance Diploma In Export Import Management</td>  		<td>One Year</td> 	</tr>     

                    <tr> <th scope="row">5</th> 	<td>Advance Diploma In Retail Management</td>  				<td>One Year</td> 	</tr>

                    <tr> <th scope="row">6</th> 	<td>Advance Diploma In Business Management</td>  			<td>One Year</td> 	</tr>                              	

					<tr> <th scope="row">7</th> 	<td>Industrial Diploma In Export Import Management</td>  	<td>Two Year</td> 	</tr>

                    <tr> <th scope="row">8</th> 	<td>Industrial Diploma In Retail Management</td>  			<td>Two Year</td> 	</tr>

                    <tr> <th scope="row">9</th> 	<td>Industrial Diploma In Business Management</td>  		<td>Two Year</td> 	</tr>

                    </tbody> 

                  </table>
		
    </div>
  </div>
</div>











<?php include("footer.php");?>