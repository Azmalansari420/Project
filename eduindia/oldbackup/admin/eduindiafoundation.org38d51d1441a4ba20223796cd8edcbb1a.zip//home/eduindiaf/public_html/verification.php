<?php include("header.php");?>



<div class="inner-banner has-base-color-overlay text-center" style="background: url(images/background/1.jpg);">
    <div class="container">
        <div class="box">
            <h3>Verification</h3>
        </div><!-- /.box -->
    </div><!-- /.container -->
</div>



	<section class="contact_us sec-padd">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 col-sm-12 col-xs-12">
                <div class="section-title">
                    <h3>Verification</h3>
                </div>
                <div class="default-form-area">
                    <form id="contact-form" name="contact_form" class="default-form" action="http://steelthemes.com/demo/html/fortune-html/inc/sendmail.php" method="post">
					
                        <div class="row clearfix">
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                
                                <div class="form-group">
                                    <input type="text" name="form_name" class="form-control" value="" placeholder="Enter Your Registration No.*" required="">
                                </div>
                            </div>
							
						
							
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    
                                    <button class="thm-btn thm-color" type="submit" data-loading-text="Please wait...">Submit</button>
                                </div>
                            </div>   

                        </div>
                    </form>
                </div>
            </div>
            
        </div>
    </div>
</section>


<?php include("footer.php");?>
