<?php include("header.php");?>


<div class="inner-banner has-base-color-overlay text-center" style="background: url(galleryimages/Sewing-Machine.jpg);">
    <div class="container">
        <div class="box">
            <h3>Sewing Machine Operator</h3>
        </div><!-- /.box -->
    </div><!-- /.container -->
</div>
<!--
<div class="breadcumb-wrapper">
    <div class="container">
        <div class="pull-left">
            <ul class="list-inline link-list">
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li>
                    <a href="javascript:;">service</a>
                </li>
                <li>
                    service single
                </li>
            </ul>
        </div>
        <div class="pull-right">
            <a href="#" class="get-qoute"><i class="fa fa-share-alt"></i>share</a>
        </div>
    </div>
</div>-->





<section class="service-single sec-padd">
    <div class="container">
        <div class="row">     
            <div class="col-md-3">
            
                <div class="service-sidebar">
                   <ul class="service-catergory">
                        <li><a href="courseoffer.php">View All Services</a> <span class="view-all-icon fa fa-cog"></span></li>
                        <li class="active"><a href="javascript:;">Dairy Farmer/Entrepreneur</a></li>
                        <li><a href="Sewing-Machine.php">Sewing Machine Operator</a></li>
                        <li><a href="Assistant-Beauty.php">Assistant Beauty Therapist</a></li>
                        <li><a href="javascript:;">Domestic Data Entry Operator</a></li>
                   </ul>
                </div>
            </div>
            <div class="col-md-9">
                <div class="outer-box">
                    <div class="img-box"><img src="galleryimages/Sewing-Machine.jpg" alt=""></div>
                    <br><br>
                    <div class="section-title">
                        <h2>Sewing Machine Operator</h2>
                    </div>
                    <div class="text">
                        <p>The textile and apparel industry is one of the largest segments of India’s economy. It is also the largest employer in the manufacturing sector. In addition, millions of others rely on the textile and apparel industry for their livelihoods. But it is highly fragmented. Most apparel sector units are family-run businesses having 50-60 sewing machines, often on contract to apparel wholesalers, usually using old production equipment and methods. There is a significant shortage of skilled manpower, essentially due to gaps in skill availability and skill needs. The need of the hour is to have a skilled workforce that will enhance productivity, profits and eventually contribute towards poverty alleviation. Sewing Machine Operators are at the entry level of the ecosystem </p>

<h4>Who is a Sewing Machine Operator?</h4>

<p>A Sewing Machine Operator is associated with the apparel sector. His/her primary responsibility is to stitch/sew fabric, fur, or synthetic materials to produce apparels. A Sewing Machine Operator should have good eyesight, eye-hand-leg coordination, motor skills and vision (including near vision, distance vision, colour vision, peripheral vision), depth perception and ability to change focus</p>

<h4>Career Progression</h4>

<p>Sewing Machine Operator → Sewing Supervisor (Line Supervisor) → Floor In-charge → Factory Manager 

Sewing Machine Operator → Quality Checker → Quality Control Executive → Quality Control In-charge </p>

<h4>Common Designations in Various Industries</h4>

<p>Stitcher, Machinist</p>
                    </div>
                 
                  
                    
                </div>
            </div>
        </div>
    </div>
</section>









<?php include("footer.php");?>