<?php include("header.php");?>

<title>Yoga Course Franchise: Edu India Foundation | 08950071777</title>		
<meta name="keywords" content="Yoga Course Franchise, Edu India Foundation"/>
<meta name="description" content="Get the Yoga Course Franchise from JKCS Edu India Foundation at Reasonable Prices." />

<div class="inner-banner has-base-color-overlay text-center" style="background: url(images/background/1.jpg);">
    <div class="container">
        <div class="box">
            <h3>Request For Franschisse</h3>
        </div><!-- /.box -->
    </div><!-- /.container -->
</div>



	<section class="about-faq sec-padd">
    <div class="container">
        <div class="section-title center">
            <h2>Edu India Foundation Skills</h2>
        </div>
        <div class="row">
            
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="accordion-box">
                    
                    <div class="accordion animated out" data-delay="0" data-animation="fadeInUp">
                        <div class="acc-btn">
                            <p class="title">Our Associates?</p>
                            <div class="toggle-icon">
                                <span class="plus fa fa-angle-right"></span><span class="minus fa fa-angle-down"></span>
                            </div>
                        </div>
                        <div class="acc-content">
                            <div class="col-md-4">
							dffsd
							</div>
							<div class="col-md-4">
							sdf
							</div>
							<div class="col-md-4">
							sdf
							</div>
                        </div>
                    </div>
                    
                    <div class="accordion animated out" data-delay="0" data-animation="fadeInUp">
                        <div class="acc-btn active">
                            <p class="title">Media Partners?</p>
                            <div class="toggle-icon">
                                <i class="plus fa fa-angle-right"></i><i class="minus fa fa-angle-down"></i>
                            </div>
                        </div>
                        <div class="acc-content collapsed">
                            <div class="col-md-4">
							dffsd
							</div>
							<div class="col-md-4">
							sdf
							</div>
							<div class="col-md-4">
							sdf
							</div>
                        </div>
                    </div>
                    
                    <div class="accordion animated out" data-delay="0" data-animation="fadeInUp">
                        <div class="acc-btn">
                            <p class="title">Silent Features?</p>
                            <div class="toggle-icon">
                                <i class="plus fa fa-angle-right"></i><i class="minus fa fa-angle-down"></i>
                            </div>
                        </div>
                        <div class="acc-content">
                            <div class="col-md-4">
							dffsd
							</div>
							<div class="col-md-4">
							sdf
							</div>
							<div class="col-md-4">
							sdf
							</div>
                        </div>
                    </div>
                    
                    


                </div>
            </div>
            
        </div>
    </div>
</section>


<?php include("footer.php");?>
