<?php include("header.php");?>
<title>Edu India Foundation | Login</title>		
<meta name="keywords" content="Edu India Foundation, JKCS Edu India Foundation"/>
<meta name="description" content="Login to JKCS Edu India Foundation to get the certified franchise for various courses." />

<img src="edu_img/login.jpg" width="100%" alt="Edu India" />


	<section class="contact_us sec-padd">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 col-sm-12 col-xs-12">
                <div class="section-title">
                    <h3>Sign In</h3>
                </div>
                <div class="default-form-area">
                    <form id="contact-form" name="contact_form" class="default-form" action="http://steelthemes.com/demo/html/fortune-html/inc/sendmail.php" method="post">
					
                        <div class="row clearfix">
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                
                                <div class="form-group">
                                    <input type="text" name="form_name" class="form-control" value="" placeholder="username*" required="">
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                
                                <div class="form-group">
                                    <input type="text" name="form_name" class="form-control" value="" placeholder="password*" required="">
                                </div>
                            </div>
							
						
							
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    
                                    <button class="thm-btn thm-color" type="submit" data-loading-text="Please wait...">Submit</button>
                                </div>
                            </div>   

                        </div>
                    </form>
                </div>
            </div>
            
        </div>
    </div>
</section>


<?php include("footer.php");?>
