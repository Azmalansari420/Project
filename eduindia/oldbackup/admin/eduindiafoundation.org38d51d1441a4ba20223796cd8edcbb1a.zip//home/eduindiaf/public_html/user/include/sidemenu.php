 <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel" style="background-color:#fff">
       	  
	     <img src="../images/logo/logo.png" style="width: 100%;" class="img-circle" alt="User Image">
        
      </div>
       
      
      <ul class="sidebar-menu" data-widget="tree">
     
         <li>
          <a href="welcome.php">
            <i class="fa fa-user"></i> <span>View Profile</span> 
          </a> 
        </li>
		 
		 
     
        <li>
          <a href="marksheet.php">
            <i class="fa fa-user"></i> <span>Mark sheet</span> 
          </a> 
        </li>

        <li>
          <a href="admit-card.php">
            <i class="fa fa-user"></i> <span>Admit Card</span> 
          </a> 
        </li>

        <li>
          <a href="http://eduindiafoundation.in/login/userlogin.aspx" target="_blank">
            <i class="fa fa-user"></i> <span>Online Study</span> 
          </a> 
        </li>
     

         <li>
          <a href="view-card.php">
            <i class="fa fa-user"></i> <span>ID Card</span> 
          </a> 
        </li>
     
     
     
        
		<li class="treeview">
          <a href="javascript:;">
            <i class="fa fa-tag"></i>
            <span>Password</span>
             <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
        <li><a href="change_password.php"><i class="fa fa-plus-circle"></i> Change Password</a></li>
        
            
          </ul>
        </li>
		 
		
		 
		 
		
	 
        
		
        	 
	 
	 
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>