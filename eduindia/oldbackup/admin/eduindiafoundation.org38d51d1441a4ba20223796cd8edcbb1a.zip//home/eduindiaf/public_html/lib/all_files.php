<?php

  //DB config.php
  include_once('db_config.php');
  
  //All Define var 
  include_once('define.php');
  
  // Function file include
  include_once('function.php');

?>