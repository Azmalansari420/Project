<?php include("header.php");?>
<title>Edu India Foundation | Contact Us</title>		
<meta name="keywords" content="Edu India Foundation, Computer Centre Franchise, NTT Course Franchise, Yoga Course Franchise.
"/>
<meta name="description" content="Contact Edu India Foundation to get the govt. Certified Computer Centre Franchise, NTT Course Franchise, Yoga Course Franchise." />
 <?php


$message = '';

function clean_text($string)
{
	$string = trim($string);
	$string = stripslashes($string);
	$string = htmlspecialchars($string);
	return $string;
}

if(isset($_POST["submit"]))
{
	
	$message = '
		<h3 align="center"> Candidate Details</h3>
		<table border="1" width="100%" cellpadding="5" cellspacing="5">
			<tr>
				<td width="30%"> Candidate Name</td>
				<td width="70%">'.$_POST["name"].'</td>
			</tr>
			<tr>
				<td width="30%">Mobile No.</td>
				<td width="70%">'.$_POST["email"].'</td>
			</tr>
			<tr>
				<td width="30%">Email Subject</td>
				<td width="70%">'.$_POST["subject"].'</td>
			</tr>
			<tr>
				<td width="30%">Email Phone</td>
				<td width="70%">'.$_POST["phone"].'</td>
			</tr>
			<tr>
				<td width="30%">Message</td>
				<td width="70%">'.$_POST["message"].'</td>
			</tr>
			
			
			
		</table>
	';

	require 'php_mail/class.phpmailer.php';
	$mail = new PHPMailer;
	$mail->IsSMTP();								//Sets Mailer to send message using SMTP
	$mail->Host = 'eduindiafoundation.org';		//Sets the SMTP hosts of your Email hosting, this for Godaddy
	//$mail->Port = '80';								//Sets the default SMTP server port
	$mail->SMTPAuth = true;							//Sets SMTP authentication. Utilizes the Username and Password variables
	$mail->Username = 'no-reply@eduindiafoundation.org';					//Sets SMTP username
	$mail->Password = 'Eduindia@123';					//Sets SMTP password
	$mail->SMTPSecure = '';							//Sets connection prefix. Options are "", "ssl" or "tls"
	$mail->From = 'info@eduindiafoundation.org';					//Sets the From email address for the message
	$mail->FromName = 'Eduindiafoundation';				//Sets the From name of the message
	$mail->AddAddress('info@eduindiafoundation.org');		//Adds a "To" address

	$mail->AddBCC('joginderkumar.sharma83@gmail.com');
	$mail->WordWrap = 50;							//Sets word wrapping on the body of the message to a given number of characters
	$mail->IsHTML(true);							//Sets message type to HTML
	//$mail->AddAttachment($path);					//Adds an attachment from a path on the filesystem
	$mail->Subject = 'eduindiafoundation';				//Sets the Subject of the message
	$mail->Body = $message;							//An HTML or plain text message body
	if($mail->Send())								//Send an Email. Return true on success or false on error
	{
		$message = 'Thank You For Contacting Us..!!';
		echo "<script type='text/javascript'>alert('$message');</script>";
		//unlink($path);
	}
	else
	{
		$message = '<div class="alert alert-danger">There is an Error</div>';
	}
}

?>
 
<img src="edu_img/contact.jpg"  width="100%" />




<section class="contact_details sec-padd">
    <div class="container">
        <div class="section-title">
            <h3 style="text-align: center;">contact details</h3>
        </div>
        
        <br><br>
        <div class="row">

            <div class="col-sm-4 col-sm-offset-1">
                <div class="default-cinfo">
                    <div class="accordion-box">
                        <!--Start single accordion box-->
                        <div class="accordion animated out" data-delay="0" data-animation="fadeInUp">
                            <div class="acc-btn active">
                                Corporate Office?
                                <div class="toggle-icon">
                                    <i class="plus fa fa-angle-right"></i><i class="minus fa fa-angle-down"></i>
                                </div>
                            </div>
                            <div class="acc-content collapsed">
                                <ul class="contact-infos">
                                    <li>
                                        <div class="icon_box">
                                            <i class="fa fa-home"></i>
                                        </div><!-- /.icon-box -->
                                        <div class="text-box">
                                            <p><b>Address:</b> <br>
											G-16/19, 2nd Floor, Rohini, Sector 15 Delhi – 110089
</p>
                                        </div><!-- /.text-box -->
                                    </li>
                                    <li>
                                        <div class="icon_box">
                                            <i class="fa fa-phone"></i>
                                        </div><!-- /.icon-box -->
                                        <div class="text-box">
                                            <p><b>Call Us:</b> <br>
+1800 891 4011 / 89-500-71777 / 819898-8587</p>
                                        </div><!-- /.text-box -->
                                    </li>
                                    <li>
                                        <div class="icon_box">
                                            <i class="fa fa-envelope"></i>
                                        </div><!-- /.icon-box -->
                                        <div class="text-box">
                                            <p><b>Mail Us:</b> <br>info@eduindiafoundation.org</p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="accordion animated out" data-delay="0" data-animation="fadeInUp">
                            <div class="acc-btn">
                                Regional Office?
                                <div class="toggle-icon">
                                    <i class="plus fa fa-angle-right"></i><i class="minus fa fa-angle-down"></i>
                                </div>
                            </div>
                            <div class="acc-content collapsed">
                                <ul class="contact-infos">
                                    <li>
                                        <div class="icon_box">
                                            <i class="fa fa-home"></i>
                                        </div><!-- /.icon-box -->
                                        <div class="text-box">
                                            <p><b>Edu India Foundation</b> <br>
											Street Agarwal Lab, Surkhab Chowk, SIRSA (Haryana)-125055
</p>
                                        </div><!-- /.text-box -->
                                    </li>                                    
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-5">
                <div class="home-google-map">
                   <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3498.4528243670766!2d77.12649421468292!3d28.735894182377194!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d011665334e45%3A0xaddbf5a0c9d7417e!2sRohini%2C+New+Delhi%2C+Delhi+110089!5e0!3m2!1sen!2sin!4v1535691138519" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>

                </div>
            </div>
        </div>
    </div>
</section>

<div class="container">
    <div class="border-bottom"></div>
</div>

<section class="contact_us sec-padd">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-sm-12 col-xs-12">
                <div class="section-title">
                    <h3>Send Your Message Us</h3>
                </div>
                <div class="default-form-area">
                    <form id="contact-form" name="contact_form" class="default-form"  method="post">
                        <div class="row clearfix">
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                
                                <div class="form-group">
                                    <input type="text" name="name" class="form-control" value="" placeholder="Your Name *" required="">
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <input type="email" name="email" class="form-control required email" value="" placeholder="Your Mail *" required="">
                                </div>
                            </div>
                             <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <input type="text" name="subject" class="form-control" value="" placeholder="Subject">
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <input type="text" name="phone" class="form-control" value="" placeholder="Phone">
                                </div>
                            </div>
                          
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <textarea name="message" class="form-control textarea required" placeholder="Your Message...."></textarea>
                                </div>
                            </div>   
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <input id="form_botcheck" name="form_botcheck" class="form-control" type="hidden" value="">
                                    <button class="thm-btn thm-color" type="submit" name="submit" data-loading-text="Please wait...">send message</button>
                                </div>
                            </div>   

                        </div>
                    </form>
                </div>
            </div>
            <!--<div class="col-md-4 col-sm-8 col-xs-12">
                <div class="section-title">
                    <h3>Your Contact</h3>
                </div>
                <div class="author-details">
                    <div class="item">
                        <h5>Human Resource:</h5>
                        <div class="img-box">
                            <img src="images/service/thumb4.jpg" alt="">
                        </div>
                        <div class="content">
                            <h5>Charles Mecky</h5>
                            <p><i class="fa fa-phone"></i>+123 456 789</p>
                            <p><i class="fa fa-envelope"></i>example@gmail.com</p>
                        </div>
                    </div>
                    <div class="item">
                        <h5>Sales Department:</h5>
                        <div class="img-box">
                            <img src="images/service/thumb5.jpg" alt="">
                        </div>
                        <div class="content">
                            <h5>Robert Fertly</h5>
                            <p><i class="fa fa-phone"></i>+123 456 789</p>
                            <p><i class="fa fa-envelope"></i>example@gmail.com</p>
                        </div>
                    </div>

                </div>-->
            </div>
        </div>
    </div>
</section>

<?php include("footer.php");?>