    <div class="ht-cta-section section pt-100 pb-50" data-overlay="dark" data-opacity="8" style="background-image: url(assets/images/bg/cta.jpg)">
        <div class="container">
            <div class="row">
                <div class="ht-cta-content text-white text-center col-12">
                    <h1> Disclaimer</h1>                    
                    <p> Alpha Consultants is a professional services provider for Staffing and Alpha Consultants services. All services provided by Alpha Consultants are independent of any brand.</p>
                </div>                
            </div>
        </div>
    </div>
    <!-- Footer Bottom Section Start -->
    <div class="ht-footer-bottom-section-one section">
        <div class="container">
            <div class="row">
                
                <!-- Footer Copyright -->
                <div class="ht-footer-copyright-one col-12">
                    <p>Copyright© 2023 Alpha Consultants LLC, All Right Reserved.</p>
                </div>
                
            </div>
        </div>
    </div><!-- Footer Bottom Section End -->
    
</div><!-- Main Wrapper End -->

<!-- JS
============================================ -->

<!-- jQuery JS -->
<script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
<!-- Popper JS -->
<script src="assets/js/popper.min.js"></script>
<!-- Bootstrap JS -->
<script src="assets/js/bootstrap.min.js"></script>
<!-- Plugins JS -->
<script src="assets/js/plugins.js"></script>
<!-- Ajax Mail -->
<script src="assets/js/ajax-mail.js"></script>
<!-- Main JS -->
<script src="assets/js/main.js"></script>

</body>

</html>